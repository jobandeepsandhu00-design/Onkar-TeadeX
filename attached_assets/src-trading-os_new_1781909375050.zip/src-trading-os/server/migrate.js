import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { pool } from "./db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dir = path.join(__dirname, "..", "migrations");

async function run() {
  const files = fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".sql"))
    .sort();

  for (const f of files) {
    const sql = fs.readFileSync(path.join(dir, f), "utf8");
    process.stdout.write(`[migrate] applying ${f} ... `);
    await pool.query(sql);
    console.log("ok");
  }
  console.log("[migrate] done");
  await pool.end();
}

run().catch((e) => {
  console.error("[migrate] failed:", e.message);
  process.exit(1);
});
