import pg from "pg";
import dotenv from "dotenv";

dotenv.config();

if (!process.env.DATABASE_URL) {
  console.error(
    "\n[db] DATABASE_URL is not set.\n" +
      "On Replit: open the Database tool and create a PostgreSQL database — it sets DATABASE_URL automatically.\n" +
      "Locally: copy .env.example to .env and fill in DATABASE_URL.\n"
  );
}

const needsSSL = /[?&]sslmode=require/.test(process.env.DATABASE_URL || "");

export const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: needsSSL ? { rejectUnauthorized: false } : undefined,
});

export const query = (text, params) => pool.query(text, params);
