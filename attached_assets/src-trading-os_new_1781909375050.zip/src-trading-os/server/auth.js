import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { query } from "./db.js";

const JWT_SECRET = process.env.JWT_SECRET || "dev-only-insecure-secret-change-me";
const TOKEN_TTL = "30d";

if (!process.env.JWT_SECRET) {
  console.warn("[auth] JWT_SECRET not set — using an insecure dev default. Set JWT_SECRET in production.");
}

const isEmail = (s) => typeof s === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);

function sign(user) {
  return jwt.sign({ uid: user.id, email: user.email }, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

export async function registerHandler(req, res) {
  const { email, password } = req.body || {};
  if (!isEmail(email)) return res.status(400).json({ error: "A valid email is required." });
  if (typeof password !== "string" || password.length < 6)
    return res.status(400).json({ error: "Password must be at least 6 characters." });

  const lower = email.toLowerCase();
  const existing = await query("SELECT id FROM users WHERE lower(email) = $1", [lower]);
  if (existing.rowCount > 0) return res.status(409).json({ error: "An account with that email already exists." });

  const hash = await bcrypt.hash(password, 10);
  const { rows } = await query(
    "INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id, email",
    [lower, hash]
  );
  const user = rows[0];
  // seed an empty state row so the first GET /state is consistent
  await query("INSERT INTO app_state (user_id, data) VALUES ($1, NULL) ON CONFLICT (user_id) DO NOTHING", [user.id]);
  res.json({ token: sign(user), user: { id: user.id, email: user.email } });
}

export async function loginHandler(req, res) {
  const { email, password } = req.body || {};
  if (!isEmail(email) || typeof password !== "string")
    return res.status(400).json({ error: "Email and password are required." });

  const { rows } = await query("SELECT id, email, password_hash FROM users WHERE lower(email) = $1", [
    email.toLowerCase(),
  ]);
  const user = rows[0];
  if (!user) return res.status(401).json({ error: "Invalid email or password." });

  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: "Invalid email or password." });

  res.json({ token: sign(user), user: { id: user.id, email: user.email } });
}

export function meHandler(req, res) {
  res.json({ user: { id: req.userId, email: req.userEmail } });
}

// Express middleware — requires a valid Bearer token.
export function requireAuth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: "unauthorized" });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.uid;
    req.userEmail = payload.email;
    next();
  } catch {
    return res.status(401).json({ error: "unauthorized" });
  }
}
