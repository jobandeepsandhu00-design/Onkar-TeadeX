import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import { query } from "./db.js";
import { registerHandler, loginHandler, meHandler, requireAuth } from "./auth.js";

dotenv.config();

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors());
app.use(express.json({ limit: "12mb" })); // trades can carry base64 image attachments

/* ---------- health ---------- */
app.get("/api/health", (_req, res) => res.json({ ok: true }));

/* ---------- auth ---------- */
app.post("/api/auth/register", wrap(registerHandler));
app.post("/api/auth/login", wrap(loginHandler));
app.get("/api/auth/me", requireAuth, meHandler);

/* ---------- per-user state (the whole journal as one JSON blob) ---------- */
app.get(
  "/api/state",
  requireAuth,
  wrap(async (req, res) => {
    const { rows } = await query("SELECT data FROM app_state WHERE user_id = $1", [req.userId]);
    const data = rows[0]?.data ?? null;
    res.json({ value: data === null ? null : JSON.stringify(data) });
  })
);

app.put(
  "/api/state",
  requireAuth,
  wrap(async (req, res) => {
    const { value } = req.body || {};
    if (typeof value !== "string") return res.status(400).json({ error: "value (JSON string) required." });
    let parsed;
    try {
      parsed = JSON.parse(value);
    } catch {
      return res.status(400).json({ error: "value must be valid JSON." });
    }
    await query(
      `INSERT INTO app_state (user_id, data, updated_at)
       VALUES ($1, $2, now())
       ON CONFLICT (user_id) DO UPDATE SET data = EXCLUDED.data, updated_at = now()`,
      [req.userId, parsed]
    );
    res.json({ ok: true });
  })
);

/* ---------- serve built client in production ---------- */
const distDir = path.join(__dirname, "..", "dist");
if (fs.existsSync(distDir)) {
  app.use(express.static(distDir));
  app.get("*", (_req, res) => res.sendFile(path.join(distDir, "index.html")));
}

/* ---------- error handler ---------- */
app.use((err, _req, res, _next) => {
  console.error("[server]", err);
  res.status(500).json({ error: "Server error." });
});

app.listen(PORT, () => console.log(`[server] listening on http://localhost:${PORT}`));

// wraps async route handlers so rejected promises hit the error handler
function wrap(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
