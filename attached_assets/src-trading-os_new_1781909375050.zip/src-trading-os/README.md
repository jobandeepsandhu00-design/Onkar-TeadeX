# SRC Trading OS — Full-Stack

A private trading journal. React + Vite front end, Express + PostgreSQL back end, with email/password accounts. Your journal data lives in Postgres, scoped to your account, so it persists across sessions (and devices, if you log in elsewhere).

## Architecture

- **Client** (`src/`) — the original single-file app, unchanged except its storage layer. It now reads/writes through `src/api.ts` instead of the Artifacts `window.storage`.
- **Server** (`server/`) — Express API: `/api/auth/*` (register, login, me) and `/api/state` (GET/PUT the user's journal). Serves the built client in production.
- **Database** — two tables: `users` and `app_state`. The journal is stored as one JSONB document per user (`app_state.data`). This mirrors how the client manages state (one object, debounced full-save), so there was no need to shred it into many tables. If you later want SQL-level per-trade analytics, the JSONB can be normalized then.

## Run on Replit

1. Create a new Replit and upload these files (or import the repo).
2. Open the **Database** tool in the left sidebar → create a **PostgreSQL** database. Replit sets `DATABASE_URL` automatically.
3. In **Secrets** (Tools → Secrets), add `JWT_SECRET` = a long random string.
4. In the Shell, run the migration once:
   ```
   npm install
   npm run db:migrate
   ```
5. Press **Run**. Replit runs `npm run prod` (build + start) and opens the app.

> Deploying via Replit's **Deploy** button: build command `npm run build`, run command `npm run start`. Make sure `DATABASE_URL` and `JWT_SECRET` are present in the deployment's secrets, and run `npm run db:migrate` once against the production database.

## Run locally

```bash
cp .env.example .env        # fill in DATABASE_URL and JWT_SECRET
npm install
npm run db:migrate          # create tables
npm run dev                 # client on :5173, API on :3001 (Vite proxies /api)
```

Production build locally:
```bash
npm run prod                # builds the client, serves everything from :3001
```

## Environment variables

| Name           | Required | Notes                                                        |
| -------------- | -------- | ------------------------------------------------------------ |
| `DATABASE_URL` | yes      | Postgres connection string. Auto-set by Replit's DB tool.    |
| `JWT_SECRET`   | yes (prod) | Signs login tokens. Falls back to an insecure dev default if unset. |
| `PORT`         | no       | Defaults to 3001.                                            |

## API

| Method | Path                 | Auth | Body                  | Returns                 |
| ------ | -------------------- | ---- | --------------------- | ----------------------- |
| POST   | `/api/auth/register` | no   | `{email, password}`   | `{token, user}`         |
| POST   | `/api/auth/login`    | no   | `{email, password}`   | `{token, user}`         |
| GET    | `/api/auth/me`       | yes  | —                     | `{user}`                |
| GET    | `/api/state`         | yes  | —                     | `{value}` (JSON string \| null) |
| PUT    | `/api/state`         | yes  | `{value}` JSON string | `{ok:true}`             |

## Notes / next steps

- Auth tokens are JWTs stored in `localStorage` and sent as `Authorization: Bearer`. Fine for a personal app. For higher security, move to httpOnly cookies.
- Attachments are stored inline as base64 inside the JSON document (the JSON body limit is 12 MB). If you start storing many large screenshots, move attachments to object storage (e.g. Replit Object Storage / S3) and keep only URLs in the document.
- There is no password reset flow yet — add one if this grows beyond personal use.
